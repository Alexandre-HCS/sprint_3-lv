<?php
namespace Models;
use Interfaces\Locavel;

// Definição da constante DIARIA_TERNO_C, que precisa ser feita se não estiver definida
define('DIARIA_TERNO_C', 100.0); // Exemplo de valor, ajuste conforme necessário

// Classe que representa um carro
class Terno_c extends Roupa implements Locavel {

    // Método para calcular o aluguel, com validação dos dias
    public function calcularAluguel(int $dias): float 
    {
        // Verificando se o valor de dias é válido (maior que 0)
        if ($dias <= 0) {
            return 0;  // Retorna 0 se o número de dias for inválido
        }
        return $dias * DIARIA_TERNO_C;  // Retorna o valor do aluguel baseado nos dias
    }

    // Método para alugar o terno
    public function alugar(): string {
        if ($this->disponivel) {
            $this->disponivel = false;
            return "Terno '{$this->nome}' alugado com sucesso!";
        }
        return "Terno '{$this->nome}' não disponível.";
    }

    // Método para devolver o terno
    public function devolver(): string {
        if (!$this->disponivel) {
            $this->disponivel = true;
            return "Terno '{$this->nome}' devolvido com sucesso!";
        }
        return "Terno '{$this->nome}' está disponível.";
    }
    
}
?>
